# Magisk Module Template

## Description

This module will modify mbn_sw.txt to enable VoLTE for Chinese Operators , Theoretical support for all Pixel models and Android versions .

## Author 

[MuXin](https://github.com/CHN-MuXin "Author")

[h@ph233.cn](h@ph233.cn "email")

## Links

[GitHub](https://github.com/CHN-MuXin/MagiskModuleEnableChinaForVoTELtoPIxel "Source code ")



---


# Magisk Pixel启用中国VoTEL 模块



## 描述

该模块通过修改 mbn_sw.txt 文件实现开启中国 VoLTE支持 以让Pixel能使用中国电信的 VoLTE通话 ，理论上支持Pixel所有型号以及安卓版本。

## 作者

[MuXin](https://github.com/CHN-MuXin "Author")

[h@ph233.cn](h@ph233.cn "email")

## 链接

[GitHub](https://github.com/CHN-MuXin/MagiskModuleEnableChinaForVoTELtoPIxel "源代码")